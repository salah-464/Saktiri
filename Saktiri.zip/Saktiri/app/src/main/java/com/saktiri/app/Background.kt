package com.saktiri.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.IOException

class SaktiriApp : Application() {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "تذكيرات سكرتيري", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object { const val CHANNEL = "reminders" }
}

object NoteSaver {
    /** Saves a note immediately, then queues AI classification + indexing for when the network is available. */
    suspend fun save(context: Context, note: Note) {
        val app = context.applicationContext
        val id = AppDatabase.get(app).noteDao().insert(note)
        enqueueClassify(app, id)
    }

    fun enqueueClassify(context: Context, id: Long) {
        val req = OneTimeWorkRequestBuilder<ClassifyWorker>()
            .setInputData(workDataOf("id" to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork("classify-$id", ExistingWorkPolicy.KEEP, req)
    }
}

class ClassifyWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getLong("id", -1L)
        if (id < 0) return Result.failure()
        val dao = AppDatabase.get(applicationContext).noteDao()
        var note = dao.get(id) ?: return Result.success()
        val prefs = Prefs(applicationContext)
        if (prefs.aiMode == AiMode.OFF || prefs.apiKey.isBlank()) return Result.success() // stays local/unsorted
        return try {
            if (!note.classified) {
                val file = if (prefs.aiMode == AiMode.FULL) FileStore.readForAi(applicationContext, note) else null
                val r = Classifier.classify(prefs, note, file)
                if (dao.get(id) == null) return Result.success() // deleted meanwhile
                note = note.copy(
                    title = r.title, category = r.category, remindAt = r.remindAt,
                    summary = r.summary, classified = true
                )
                dao.update(note)
                ReminderScheduler.schedule(applicationContext, note)
            }
            if (note.embedding == null) {
                val vec = GeminiClient.embed(prefs, Vec.docText(note), false)
                note = note.copy(embedding = Vec.toBytes(vec))
                dao.update(note)
            }
            Result.success()
        } catch (e: IOException) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}

object ReminderScheduler {
    private fun pending(context: Context, note: Note): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
            .putExtra("title", note.title.ifBlank { "تذكير" })
            .putExtra("body", note.text.take(200))
        return PendingIntent.getBroadcast(
            context, note.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, note: Note) {
        val t = note.remindAt ?: return
        if (t <= System.currentTimeMillis()) return
        val am = context.getSystemService(AlarmManager::class.java)
        // Inexact alarm: no special permission needed, may fire a few minutes late.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pending(context, note))
    }

    fun cancel(context: Context, note: Note) {
        context.getSystemService(AlarmManager::class.java).cancel(pending(context, note))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val title = intent.getStringExtra("title") ?: "تذكير"
        val body = intent.getStringExtra("body") ?: ""
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, SaktiriApp.CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(System.currentTimeMillis().toInt(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.get(app).noteDao().upcoming(System.currentTimeMillis())
                    .forEach { ReminderScheduler.schedule(app, it) }
            } finally {
                pending.finish()
            }
        }
    }
}
