package com.saktiri.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            SaktiriTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showIntro by rememberSaveable { mutableStateOf(true) }
    val snackbar = remember { SnackbarHostState() }

    // State that must survive switching tabs (scroll position, the chat).
    val libraryState = rememberLazyListState()
    val turns = remember { mutableStateListOf<ChatTurn>() }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        delay(1000)
        showIntro = false
    }

    // Back from another tab returns to the library first.
    BackHandler(enabled = tab != 0 && !showIntro) { tab = 0 }

    fun go(i: Int) {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (i == tab && i == 0) {
            scope.launch { libraryState.animateScrollToItem(0) } // tap the active tab = scroll to top
        } else {
            tab = i
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { go(0) },
                        icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                        label = { Text("المكتبة") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { go(1) },
                        icon = { Icon(Icons.Filled.Face, contentDescription = null) },
                        label = { Text("اسأل") }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { go(2) },
                        icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                        label = { Text("الإعدادات") }
                    )
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize()) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        // RTL layout: higher tab index sits further left, so content slides in from the left.
                        val dir = if (targetState > initialState) -1 else 1
                        (slideInHorizontally(animationSpec = tween(280)) { full -> dir * full / 8 } +
                            fadeIn(animationSpec = tween(240))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(280)) { full -> -dir * full / 8 } +
                                fadeOut(animationSpec = tween(160)))
                    },
                    label = "tabs"
                ) { t ->
                    when (t) {
                        0 -> LibraryScreen(snackbar, libraryState) { go(2) }
                        1 -> AskScreen(turns)
                        else -> SettingsScreen(snackbar)
                    }
                }
            }
        }

        // Short welcome animation with the mascot (tap to skip).
        AnimatedVisibility(
            visible = showIntro,
            enter = fadeIn(tween(150)),
            exit = fadeOut(tween(450))
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFF2B2D7A))
                    .pointerInput(Unit) { detectTapGestures { showIntro = false } },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Mascot(size = 150.dp)
                    Text(
                        "سكرتيري",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        "ذاكرتك الثانية",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFD3C8FF)
                    )
                }
            }
        }
    }
}
