package com.saktiri.app

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Pixel sprite inspired by the 👾 emoji. Two frames = the little "arms" wiggle.
private val FRAME_A = listOf(
    "..#.....#..",
    "...#...#...",
    "..#######..",
    ".##.###.##.",
    "###########",
    "#.#######.#",
    "#.#.....#.#",
    "...##.##..."
)
private val FRAME_B = listOf(
    "..#.....#..",
    "#..#...#..#",
    "#.#######.#",
    "###.###.###",
    "###########",
    ".#########.",
    "..#.....#..",
    ".#.......#."
)
private val BODY_TOP = Color(0xFFA78BFF)
private val BODY_BOTTOM = Color(0xFF5B3FD6)
private val EYE_DARK = Color(0xFF1B1464)

/**
 * Saktiri's mascot: bobs up and down, wiggles, blinks, looks around.
 * thinking = faster and busier (used while the assistant searches). animated = false draws a still frame.
 */
@Composable
fun Mascot(
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    thinking: Boolean = false,
    animated: Boolean = true
) {
    if (animated) {
        val t = rememberInfiniteTransition(label = "mascot")
        val bob = t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(if (thinking) 450 else 1300, easing = FastOutSlowInEasing),
                RepeatMode.Reverse
            ),
            label = "bob"
        )
        val frame = t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(if (thinking) 500 else 900, easing = LinearEasing)),
            label = "frame"
        )
        val blink = t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing)),
            label = "blink"
        )
        val look = t.animateFloat(
            initialValue = -1f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(if (thinking) 900 else 2600), RepeatMode.Reverse),
            label = "look"
        )
        MascotCanvas(modifier, size, bob, frame, blink, look)
    } else {
        val zero = remember { mutableStateOf(0f) }
        MascotCanvas(modifier, size, zero, zero, zero, zero)
    }
}

@Composable
private fun MascotCanvas(
    modifier: Modifier,
    sizeDp: Dp,
    bob: State<Float>,
    frame: State<Float>,
    blink: State<Float>,
    look: State<Float>
) {
    Canvas(modifier.size(sizeDp)) {
        val s = this.size.minDimension
        val cell = s / 12.5f
        val w = 11 * cell
        val h = 8 * cell
        val ox = (s - w) / 2f
        val baseY = (s - h) / 2f + cell * 0.6f
        val oy = baseY - bob.value * cell * 0.8f
        val grid = if (frame.value < 0.5f) FRAME_A else FRAME_B
        val brush = Brush.verticalGradient(
            colors = listOf(BODY_TOP, BODY_BOTTOM),
            startY = oy,
            endY = oy + h
        )

        // soft shadow that shrinks when the mascot floats up
        val sh = 1f - bob.value * 0.25f
        drawOval(
            color = Color.Black.copy(alpha = 0.14f),
            topLeft = Offset(s / 2f - cell * 3f * sh, baseY + h + cell * 0.7f),
            size = Size(cell * 6f * sh, cell * 0.8f)
        )

        for (r in 0 until 8) {
            for (c in 0 until 11) {
                if (grid[r][c] == '#') {
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(ox + c * cell, oy + r * cell),
                        size = Size(cell * 0.96f, cell * 0.96f),
                        cornerRadius = CornerRadius(cell * 0.2f)
                    )
                }
            }
        }

        // eyes sit in the two holes of row 3 (columns 3 and 7)
        val blinking = blink.value > 0.95f
        for (ec in intArrayOf(3, 7)) {
            val ex = ox + ec * cell
            val ey = oy + 3 * cell
            if (blinking) {
                drawRoundRect(
                    color = EYE_DARK,
                    topLeft = Offset(ex, ey + cell * 0.42f),
                    size = Size(cell * 0.96f, cell * 0.16f),
                    cornerRadius = CornerRadius(cell * 0.08f)
                )
            } else {
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(ex, ey),
                    size = Size(cell * 0.96f, cell * 0.96f),
                    cornerRadius = CornerRadius(cell * 0.2f)
                )
                drawRoundRect(
                    color = EYE_DARK,
                    topLeft = Offset(ex + cell * 0.28f + look.value * cell * 0.18f, ey + cell * 0.26f),
                    size = Size(cell * 0.42f, cell * 0.5f),
                    cornerRadius = CornerRadius(cell * 0.1f)
                )
            }
        }
    }
}
