package com.saktiri.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

data class ChatTurn(val id: Long, val question: String, val answer: String?, val sources: List<Note>)

/** [turns] is hoisted to the app root so the conversation survives switching tabs. */
@Composable
fun AskScreen(turns: SnapshotStateList<ChatTurn>) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val mode = prefs.aiMode

    fun send(q: String) {
        val question = q.trim()
        if (question.isEmpty() || busy) return
        busy = true
        input = ""
        val id = System.nanoTime()
        turns.add(ChatTurn(id, question, null, emptyList()))
        scope.launch {
            val r = try {
                Assistant.ask(ctx, question)
            } catch (e: Exception) {
                AskResult("تعذر الحصول على جواب: ${e.message}", emptyList())
            }
            val pos = turns.indexOfFirst { it.id == id }
            if (pos >= 0) turns[pos] = turns[pos].copy(answer = r.answer, sources = r.sources)
            busy = false
        }
    }

    LaunchedEffect(turns.size, turns.lastOrNull()?.answer) {
        if (turns.isNotEmpty()) listState.animateScrollToItem(turns.lastIndex)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "اسأل ذاكرتك",
            subtitle = "جاوب من ملاحظاتك وملفاتك المحفوظة",
            leading = { Mascot(size = 52.dp, thinking = busy) }
        ) {
            PrivacyBadge(mode) {}
        }
        if (mode == AiMode.OFF) {
            Text(
                "وضع الخصوصية مغلق: بحث محلي بدون ذكاء اصطناعي.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (turns.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Mascot(size = 120.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "اسألني عن أي شي حفظته",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    listOf("وين خطة الجامعة؟", "كم علي ديون؟", "شو مواعيدي القادمة؟", "لخّصلي أفكاري").forEach { s ->
                        SuggestionChip(
                            onClick = { send(s) },
                            label = { Text(s) },
                            modifier = Modifier.padding(vertical = 3.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(turns, key = { it.id }) { t -> TurnItem(t, ctx) }
                }
            }
        }

        Surface(color = MaterialTheme.colorScheme.surfaceContainer, tonalElevation = 3.dp) {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("اسأل عن أي شي حفظته...") },
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { send(input) }, enabled = input.isNotBlank() && !busy) { Text("اسأل") }
            }
        }
    }
}

@Composable
private fun TurnItem(t: ChatTurn, ctx: Context) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                Text(t.question, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyLarge)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Bottom
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                if (t.answer == null) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("عم فتش بذاكرتك...", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    SelectionContainer {
                        Text(t.answer, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
            Spacer(Modifier.width(6.dp))
            Mascot(size = 40.dp, thinking = t.answer == null, animated = t.answer == null)
        }
        if (t.sources.isNotEmpty()) {
            Text(
                "المصادر",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 10.dp)
            )
            t.sources.forEach { n -> SourceChip(n, ctx) }
        }
    }
}

@Composable
private fun SourceChip(n: Note, ctx: Context) {
    val st = styleOf(n.category)
    val kws = remember(n.title, n.text, n.summary, n.fileName) { Keywords.extract(n, 3) }
    Surface(
        onClick = { if (n.fileMode != null) FileStore.open(ctx, n) },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(st.emoji, fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    n.title.ifBlank { n.fileName ?: n.text.take(40) },
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (kws.isNotEmpty()) {
                    Text(
                        kws.joinToString("  ") { "#$it" },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (n.fileName != null) {
                    Text(
                        "${fileEmoji(n.mimeType)} ${n.fileName} · 📍 ${FileStore.locationLabel(n)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (n.fileMode != null) {
                Text("افتح", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
