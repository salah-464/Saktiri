package com.saktiri.app

import android.content.Context
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ln

/**
 * Static word vectors (Arabic + English), loaded from wv.bin (built by tools/make_wordvectors.py, < 10 MB).
 * File layout (little-endian): "SKW1" | uint32 N | uint16 D | N x (uint8 len + utf8 word) | N x uint8 weight
 *                              | N x float32 scale | N*D x int8 vectors
 */
class WordVectors private constructor(
    val dim: Int,
    private val index: HashMap<String, Int>,
    private val weights: ByteArray,
    private val scales: FloatArray,
    private val vecs: ByteArray
) {
    val size: Int get() = scales.size

    private fun lookup(tok: String): Int? {
        index[tok]?.let { return it }
        var t = tok
        if (t.length > 3 && t.startsWith("ال")) {
            t = t.substring(2)
            index[t]?.let { return it }
        }
        if (t.length > 3 && t[0] in "وبلفك") {
            val r = t.substring(1)
            index[r]?.let { return it }
            if (r.length > 3 && r.startsWith("ال")) index[r.substring(2)]?.let { return it }
        }
        for (suf in SUFFIXES) {
            if (t.length > suf.length + 2 && t.endsWith(suf)) {
                index[t.dropLast(suf.length)]?.let { return it }
            }
        }
        return null
    }

    /** Weighted average of the word vectors in [text], L2-normalised; null if no known word. */
    fun embed(text: String): FloatArray? {
        val acc = FloatArray(dim)
        var hits = 0
        for (tok in TextUtil.norm(text).split(TOKEN_SPLIT)) {
            if (tok.length < 2) continue
            val i = lookup(tok) ?: continue
            val s = scales[i] * ((weights[i].toInt() and 0xFF) / 20f)
            val base = i * dim
            for (j in 0 until dim) acc[j] += vecs[base + j] * s
            hits++
        }
        return if (hits == 0) null else Vec.normalize(acc)
    }

    companion object {
        private val TOKEN_SPLIT = Regex("[^\\p{L}\\p{N}]+")
        private val SUFFIXES = listOf("ing", "ed", "es", "s", "ات", "ون", "ين", "ان", "ها", "هم", "ه", "ي")

        fun parse(bytes: ByteArray): WordVectors? = try {
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val magic = ByteArray(4)
            bb.get(magic)
            if (String(magic, Charsets.US_ASCII) != "SKW1") {
                null
            } else {
                val n = bb.int
                val d = bb.short.toInt() and 0xFFFF
                if (n <= 0 || d <= 0) {
                    null
                } else {
                    val index = HashMap<String, Int>(n * 2)
                    for (i in 0 until n) {
                        val len = bb.get().toInt() and 0xFF
                        index[String(bytes, bb.position(), len, Charsets.UTF_8)] = i
                        bb.position(bb.position() + len)
                    }
                    val weights = ByteArray(n)
                    bb.get(weights)
                    val scales = FloatArray(n)
                    bb.asFloatBuffer().get(scales)
                    bb.position(bb.position() + 4 * n)
                    val vecs = ByteArray(n * d)
                    bb.get(vecs)
                    WordVectors(d, index, weights, scales, vecs)
                }
            }
        } catch (e: Exception) {
            null
        }
    }
}

/**
 * Fully offline search: (1) character-trigram BM25 (typos, Arabic morphology) fused with
 * (2) word-vector semantic similarity when wv.bin is installed. Nothing here touches the network.
 */
object LocalSearch {
    /** Minimum cosine for a semantic hit. Tune after trying real notes. */
    const val SEM_MIN = 0.30f

    @Volatile private var wv: WordVectors? = null
    private val docCache = HashMap<Long, Pair<Int, FloatArray?>>()

    private fun modelFile(ctx: Context) = File(ctx.filesDir, "wv.bin")

    fun isLoaded(): Boolean = wv != null

    fun info(): String? = wv?.let { "${it.size} كلمة · ${it.dim} بُعد" }

    /** Loads wv.bin from app storage (imported) or from assets. Safe to call repeatedly. */
    fun load(ctx: Context) {
        if (wv != null) return
        val bytes = try {
            val f = modelFile(ctx)
            if (f.exists()) f.readBytes() else ctx.assets.open("wv.bin").use { it.readBytes() }
        } catch (e: Exception) {
            return
        }
        val parsed = WordVectors.parse(bytes) ?: return
        wv = parsed
        synchronized(docCache) { docCache.clear() }
    }

    fun importModel(ctx: Context, uri: Uri): Boolean = try {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        val parsed = if (bytes == null) null else WordVectors.parse(bytes)
        if (bytes == null || parsed == null) {
            false
        } else {
            modelFile(ctx).writeBytes(bytes)
            wv = parsed
            synchronized(docCache) { docCache.clear() }
            true
        }
    } catch (e: Exception) {
        false
    }

    fun remove(ctx: Context) {
        modelFile(ctx).delete()
        wv = null
        synchronized(docCache) { docCache.clear() }
    }

    /** Ranked notes for [query]; empty when nothing is relevant enough. */
    fun search(notes: List<Note>, query: String, limit: Int = 50): List<Note> {
        if (query.isBlank() || notes.isEmpty()) return emptyList()
        val score = HashMap<Long, Double>()
        lexicalRank(notes, query).forEachIndexed { i, n -> score[n.id] = (score[n.id] ?: 0.0) + 1.0 / (60 + i) }
        semanticRank(notes, query).forEachIndexed { i, n -> score[n.id] = (score[n.id] ?: 0.0) + 1.0 / (60 + i) }
        val byId = notes.associateBy { it.id }
        return score.entries.sortedByDescending { it.value }.take(limit).mapNotNull { byId[it.key] }
    }

    // ---------- lexical: character trigrams + BM25 ----------

    private val TOKEN_SPLIT = Regex("[^\\p{L}\\p{N}]+")

    private fun grams(text: String): List<String> {
        val out = ArrayList<String>()
        for (w in TextUtil.norm(text).split(TOKEN_SPLIT)) {
            var t = w
            if (t.length < 2) continue
            if (t.length > 3 && t.startsWith("ال")) t = t.substring(2)
            val p = "^" + t + "$"
            for (i in 0..p.length - 3) out.add(p.substring(i, i + 3))
        }
        return out
    }

    private fun lexicalRank(notes: List<Note>, query: String): List<Note> {
        val qg = grams(query).toSet()
        if (qg.isEmpty()) return emptyList()
        val docs = notes.map { grams(Vec.docText(it)) }
        val n = notes.size
        val avg = (docs.sumOf { it.size }.toDouble() / n).coerceAtLeast(1.0)
        val df = HashMap<String, Int>()
        for (d in docs) for (g in d.toSet()) if (g in qg) df[g] = (df[g] ?: 0) + 1
        val minOverlap = if (qg.size >= 4) 2 else 1
        val scored = ArrayList<Pair<Note, Double>>()
        for ((i, d) in docs.withIndex()) {
            val tf = HashMap<String, Int>()
            for (g in d) if (g in qg) tf[g] = (tf[g] ?: 0) + 1
            if (tf.size < minOverlap) continue
            var s = 0.0
            for ((g, f) in tf) {
                val dfg = df[g] ?: 0
                val idf = ln(1 + (n - dfg + 0.5) / (dfg + 0.5))
                s += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * d.size / avg))
            }
            scored.add(notes[i] to s)
        }
        val max = scored.maxOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second >= 0.35 * max }.sortedByDescending { it.second }.map { it.first }
    }

    // ---------- semantic: static word vectors ----------

    private fun docVec(m: WordVectors, note: Note): FloatArray? {
        val text = Vec.docText(note)
        val h = text.hashCode()
        synchronized(docCache) {
            val c = docCache[note.id]
            if (c != null && c.first == h) return c.second
        }
        val v = m.embed(text)
        synchronized(docCache) { docCache[note.id] = h to v }
        return v
    }

    private fun semanticRank(notes: List<Note>, query: String): List<Note> {
        val m = wv ?: return emptyList()
        val qv = m.embed(query) ?: return emptyList()
        val scored = ArrayList<Pair<Note, Float>>()
        for (note in notes) {
            val dv = docVec(m, note) ?: continue
            val c = Vec.dot(qv, dv)
            if (c >= SEM_MIN) scored.add(note to c)
        }
        return scored.sortedByDescending { it.second }.take(30).map { it.first }
    }
}
