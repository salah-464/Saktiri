package com.saktiri.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Invisible activity: receives shared text and/or files, saves them, shows a toast, closes.
 * Files are copied while this activity is alive, because the share permission is temporary.
 */
class ShareReceiverActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val caption = intent?.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        val uris = extractUris(intent)
        if (uris.isEmpty() && caption.isEmpty()) {
            finish()
            return
        }
        val app = application as SaktiriApp
        lifecycleScope.launch {
            var saved = 0
            var failed = 0
            var lastError = ""
            withContext(Dispatchers.IO) {
                if (uris.isEmpty()) {
                    NoteSaver.save(app, Note(text = caption))
                    saved = 1
                } else {
                    uris.forEach { u ->
                        try {
                            NoteSaver.save(app, FileStore.copyIn(app, u, caption))
                            saved++
                        } catch (e: Exception) {
                            failed++
                            lastError = e.message.orEmpty()
                        }
                    }
                }
            }
            val msg = when {
                failed > 0 -> "تعذر حفظ $failed ملف. $lastError"
                uris.isEmpty() -> "تم الحفظ في سكرتيري 🧠"
                else -> "تم حفظ $saved ملف في سكرتيري 🧠"
            }
            Toast.makeText(this@ShareReceiverActivity, msg, Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Suppress("DEPRECATION")
    private fun extractUris(i: Intent?): List<Uri> {
        if (i == null) return emptyList()
        return if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            (if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)) ?: emptyList()
        } else {
            val u = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            listOfNotNull(u)
        }
    }
}
