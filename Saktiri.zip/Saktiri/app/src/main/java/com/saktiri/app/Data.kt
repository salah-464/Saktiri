package com.saktiri.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val title: String = "",
    val category: String = "unsorted", // university | debt | appointment | idea | other | unsorted
    val createdAt: Long = System.currentTimeMillis(),
    val remindAt: Long? = null,
    val classified: Boolean = false,
    val summary: String = "",          // AI summary (for files: what is inside, key dates/names)
    val fileUri: String? = null,       // copy: absolute path in app storage | link: content:// uri
    val fileName: String? = null,
    val mimeType: String? = null,
    val fileMode: String? = null,      // "copy" | "link" | null (plain text note)
    val embedding: ByteArray? = null   // semantic vector (768 floats)
)

@Dao
interface NoteDao {
    @Insert suspend fun insert(note: Note): Long
    @Update suspend fun update(note: Note)
    @Delete suspend fun delete(note: Note)

    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    suspend fun getAll(): List<Note>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun get(id: Long): Note?

    @Query("SELECT * FROM notes WHERE remindAt IS NOT NULL AND remindAt > :now")
    suspend fun upcoming(now: Long): List<Note>

    @Query("SELECT * FROM notes WHERE classified = 0 OR embedding IS NULL")
    suspend fun needsProcessing(): List<Note>

    @Query("UPDATE notes SET embedding = NULL")
    suspend fun clearEmbeddings()
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE notes ADD COLUMN summary TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE notes ADD COLUMN fileUri TEXT")
        db.execSQL("ALTER TABLE notes ADD COLUMN fileName TEXT")
        db.execSQL("ALTER TABLE notes ADD COLUMN mimeType TEXT")
        db.execSQL("ALTER TABLE notes ADD COLUMN fileMode TEXT")
        db.execSQL("ALTER TABLE notes ADD COLUMN embedding BLOB")
    }
}

@Database(entities = [Note::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "saktiri.db"
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }
    }
}

/** Privacy level. OFF = nothing ever leaves the phone. TEXT = text only. FULL = text + image/PDF contents. */
object AiMode {
    const val OFF = "off"
    const val TEXT = "text"
    const val FULL = "full"
}

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("saktiri", Context.MODE_PRIVATE)
    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()
    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) = sp.edit().putString("model", v.trim()).apply()
    var aiMode: String
        get() = sp.getString("ai_mode", AiMode.OFF) ?: AiMode.OFF
        set(v) = sp.edit().putString("ai_mode", v).apply()
    var quickNotif: Boolean
        get() = sp.getBoolean("quick_notif", false)
        set(v) = sp.edit().putBoolean("quick_notif", v).apply()
    var embedModel: String
        get() = sp.getString("embed_model", "gemini-embedding-001") ?: "gemini-embedding-001"
        set(v) = sp.edit().putString("embed_model", v.trim()).apply()
}
