package com.saktiri.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(snackbar: SnackbarHostState) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val dao = remember { AppDatabase.get(ctx).noteDao() }
    val notes by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(prefs.aiMode) }
    var key by remember { mutableStateOf(prefs.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(prefs.model) }
    var embedModel by remember { mutableStateOf(prefs.embedModel) }

    var quick by remember { mutableStateOf(prefs.quickNotif) }
    var localInfo by remember { mutableStateOf(LocalSearch.info()) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { LocalSearch.load(ctx) }
        localInfo = LocalSearch.info()
    }

    fun say(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { LocalSearch.importModel(ctx, uri) }
            localInfo = LocalSearch.info()
            say(if (ok) "تم تثبيت نموذج البحث المحلي ✅" else "الملف مش صالح (لازم wv.bin من السكريبت)")
        }
    }

    fun processPending() {
        scope.launch {
            val list = dao.needsProcessing()
            list.forEach { NoteSaver.enqueueClassify(ctx, it.id) }
            snackbar.showSnackbar("تم طلب معالجة ${list.size} عنصر")
        }
    }

    val files = notes.count { it.fileMode != null }
    val indexed = notes.count { it.embedding != null }
    val pending = notes.count { !it.classified || it.embedding == null }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("الإعدادات", "تحكم بخصوصيتك وبالذكاء الاصطناعي")

        Section("🔐 الخصوصية") {
            PrivacyOption(
                selected = mode == AiMode.OFF,
                title = "🔒 مغلق (الأكثر خصوصية)",
                desc = "ما في أي شي بيطلع من جوالك. البحث بالكلمات، والتصنيف يدوي، وما في تذكيرات تلقائية."
            ) { mode = AiMode.OFF; prefs.aiMode = AiMode.OFF; say("وضع الخصوصية: مغلق") }
            PrivacyOption(
                selected = mode == AiMode.TEXT,
                title = "📝 نص فقط",
                desc = "بينبعت لـGoogle نص ملاحظاتك وأسماء الملفات. محتوى الصور وPDF ما بيطلع."
            ) {
                mode = AiMode.TEXT; prefs.aiMode = AiMode.TEXT; say("وضع الخصوصية: نص فقط")
                if (prefs.apiKey.isNotBlank()) processPending()
            }
            PrivacyOption(
                selected = mode == AiMode.FULL,
                title = "📎 نص + ملفات",
                desc = "بينبعت كمان محتوى الصور وPDF (حتى 10MB) ليقراها الذكاء الاصطناعي."
            ) {
                mode = AiMode.FULL; prefs.aiMode = AiMode.FULL; say("وضع الخصوصية: نص + ملفات")
                if (prefs.apiKey.isNotBlank()) processPending()
            }
        }

        Section("⚡ الحفظ السريع (واتساب، تيليجرام...)") {
            Text(
                "1) مشاركة ← سكرتيري (للرسائل اللي فيها زر مشاركة)\n2) حدّد النص ← ⋮ ← «احفظ في سكرتيري» (بالتطبيقات اللي فيها تحديد عادي)\n3) انسخ الرسالة، ثم اضغط الإشعار أو بلاطة «احفظ الحافظة» بالإعدادات السريعة أو اضغط مطولًا على أيقونة التطبيق ← «احفظ اللي نسخته»",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("إشعار الحفظ السريع", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(
                    checked = quick,
                    onCheckedChange = {
                        quick = it
                        prefs.quickNotif = it
                        if (it) QuickNotif.show(ctx) else QuickNotif.hide(ctx)
                    }
                )
            }
        }

        Section("🔎 البحث الذكي بدون نت") {
            Text(
                if (localInfo != null) "✅ جاهز: $localInfo" else "غير مثبت: البحث حاليًا بالكلمات والحروف فقط.",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "ملف صغير (أقل من 10MB) بيعطي التطبيق فهمًا للمعنى بدون إنترنت وبدون إرسال أي شي. بتجهزه مرة وحدة من Colab بسكريبت tools/make_wordvectors.py.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { importPicker.launch(arrayOf("*/*")) }) { Text("📥 استيراد wv.bin") }
                if (localInfo != null) {
                    TextButton(onClick = {
                        LocalSearch.remove(ctx)
                        localInfo = LocalSearch.info()
                        say("تم حذف النموذج المحلي")
                    }) { Text("حذف") }
                }
            }
        }

        Section("🔑 اتصال الذكاء الاصطناعي") {
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("مفتاح Gemini API") },
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "إخفاء" else "إظهار") } },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
            Button(
                onClick = {
                    prefs.apiKey = key
                    say("تم حفظ المفتاح")
                    if (mode != AiMode.OFF && key.isNotBlank()) processPending()
                },
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("حفظ المفتاح") }
            TextButton(onClick = { advanced = !advanced }) { Text(if (advanced) "إخفاء الإعدادات المتقدمة" else "إعدادات متقدمة") }
            AnimatedVisibility(visible = advanced) {
                Column {
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("موديل التصنيف والأجوبة") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = embedModel,
                        onValueChange = { embedModel = it },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        label = { Text("موديل البحث بالمعنى (Embedding)") },
                        singleLine = true
                    )
                    FilledTonalButton(
                        onClick = {
                            val newEmbed = embedModel.trim()
                            if (newEmbed != prefs.embedModel) {
                                // Old vectors have a different shape/meaning: drop them so they are rebuilt.
                                scope.launch { dao.clearEmbeddings() }
                            }
                            prefs.model = model
                            prefs.embedModel = newEmbed
                            say("تم حفظ الموديلات")
                        },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("حفظ الموديلات") }
                }
            }
        }

        Section("📊 مكتبتك") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("${notes.size}", "عنصر")
                Stat("$files", "ملف")
                Stat("$indexed", "مفهرس")
                Stat("$pending", "معلق")
            }
            FilledTonalButton(
                onClick = { processPending() },
                enabled = mode != AiMode.OFF && pending > 0,
                modifier = Modifier.padding(top = 12.dp)
            ) { Text("صنّف وافهرس العناصر المعلقة") }
        }

        Section("ℹ️ ملاحظات مهمة") {
            Text(
                "• المفتاح المجاني بيسمح لـGoogle تستخدم المحتوى لتحسين منتجاتها وممكن مراجعين بشر يقروه. للمحتوى الخاص استخدم وضع «مغلق» أو مفتاح بفوترة مفعّلة.\n• النسخ الاحتياطي السحابي معطل للتطبيق.\n• لضمان كامل: احذف صلاحية INTERNET من الـManifest.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PrivacyOption(selected: Boolean, title: String, desc: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .selectable(selected = selected, onClick = onClick, role = Role.RadioButton)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            RadioButton(selected = selected, onClick = null)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
