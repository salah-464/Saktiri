package com.saktiri.app

/**
 * Offline keyword extraction (no network, no model): picks the words that best describe a note
 * from its title, text, AI summary (if any) and file name.
 */
object Keywords {
    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")
    private val DIAC = Regex("[\\u064B-\\u065F\\u0670\\u0640]")

    // Raw spellings on purpose: "على" (on) is a stop word but "علي" (a name) is not.
    private val STOP = setOf(
        "في", "من", "إلى", "الى", "على", "عن", "مع", "هذا", "هذه", "هذي", "ذلك", "تلك", "هناك", "هنا",
        "التي", "الذي", "الذين", "اللي", "كان", "كانت", "يكون", "تكون", "هو", "هي", "هم", "هن", "نحن",
        "انا", "أنا", "انت", "أنت", "أن", "ان", "إن", "لا", "لم", "لن", "ما", "ماذا", "كيف", "متى",
        "أين", "اين", "وين", "شو", "ايش", "كم", "هاد", "هاي", "هيك", "بس", "كل", "بعض", "او", "أو",
        "ثم", "قد", "حتى", "بعد", "قبل", "عند", "لكن", "اذا", "إذا", "لو", "يا", "ايضا", "أيضا",
        "فقط", "جدا", "كمان", "عشان", "لان", "لأن", "مثل", "بين", "خلال", "منذ", "لها", "له", "لهم",
        "به", "بها", "فيها", "فيه", "منه", "منها", "عليه", "عليها", "الي", "إلي", "بعدين", "هلا",
        "ليش", "مين", "مش", "مو", "شي", "اشي", "اي", "أي", "كذا", "دي", "ده", "ايه", "إيه", "يوم",
        "the", "an", "and", "or", "of", "to", "in", "on", "for", "with", "is", "are", "was", "were",
        "be", "been", "it", "this", "that", "these", "those", "at", "by", "from", "as", "but", "not",
        "no", "if", "so", "do", "does", "did", "have", "has", "had", "you", "he", "she", "we", "they",
        "my", "your", "our", "their", "me", "him", "her", "us", "them", "will", "would", "can",
        "could", "should", "may", "might", "just", "about", "into", "than", "then", "there", "here",
        "what", "which", "who", "when", "where", "how", "why", "also", "very", "too", "all", "any",
        "some", "more", "most", "other", "such", "only", "own", "same"
    )

    private class Acc(val display: String, val first: Int) {
        var score = 0.0
    }

    /** Removes common Arabic attached prefixes: ال، وال، بال، كال، فال، لل */
    private fun stripPrefix(w: String): String {
        for (p in listOf("وال", "بال", "كال", "فال")) {
            if (w.length > p.length + 2 && w.startsWith(p)) return w.substring(p.length)
        }
        if (w.length > 4 && w.startsWith("لل")) return w.substring(2)
        if (w.length > 3 && w.startsWith("ال")) return w.substring(2)
        return w
    }

    fun extract(note: Note, max: Int = 4): List<String> {
        val sources = listOf(
            note.title to 2.0,
            note.summary to 1.2,
            note.text to 1.0,
            (note.fileName?.substringBeforeLast('.') ?: "") to 1.5
        )
        val acc = LinkedHashMap<String, Acc>()
        var pos = 0
        for ((text, weight) in sources) {
            for (raw in text.split(SPLIT)) {
                if (raw.isEmpty()) continue
                pos++
                val t = DIAC.replace(raw, "")
                if (t.lowercase() in STOP) continue
                if (t.all { it.isDigit() }) continue
                val core = stripPrefix(t)
                if (core.length < 3) continue
                val key = TextUtil.norm(core)
                val a = acc.getOrPut(key) { Acc(core, pos) }
                a.score += weight * (1.0 + minOf(core.length, 8) / 16.0)
            }
        }
        return acc.values
            .sortedWith(compareByDescending<Acc> { it.score }.thenBy { it.first })
            .take(max)
            .map { it.display }
    }
}
