package com.saktiri.app

import android.content.ClipboardManager
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface LibRow {
    data class Header(val label: String) : LibRow
    data class Item(val note: Note) : LibRow
}

@Composable
fun LibraryScreen(snackbar: SnackbarHostState, listState: LazyListState, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val dao = remember { AppDatabase.get(ctx).noteDao() }
    val notes by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var filter by rememberSaveable { mutableStateOf<String?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Note?>(null) }
    val mode = prefs.aiMode

    // Back clears the search/filter first, then leaves the tab (handled in AppRoot).
    BackHandler(enabled = search.isNotEmpty() || filter != null) {
        search = ""
        filter = null
    }

    fun say(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    // Copy mode: duplicates the file inside the app (safe if the original is moved/deleted).
    val copyPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    NoteSaver.save(ctx, FileStore.copyIn(ctx, uri, ""))
                    "تم حفظ نسخة من الملف"
                } catch (e: Exception) {
                    "تعذر حفظ الملف: ${e.message}"
                }
            }
            say(msg)
        }
    }
    // Link mode: remembers only where the file is, and opens it from there later.
    val linkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            scope.launch {
                val msg = withContext(Dispatchers.IO) {
                    try {
                        NoteSaver.save(ctx, FileStore.linked(ctx, uri, ""))
                        "تم ربط الملف (حفظنا مكانه فقط)"
                    } catch (e: Exception) {
                        "تعذر ربط الملف: ${e.message}"
                    }
                }
                say(msg)
            }
        }
    }

    // Offline smart search: trigram BM25 + word vectors (if wv.bin is installed). No network.
    var semReady by remember { mutableStateOf(LocalSearch.isLoaded()) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { LocalSearch.load(ctx) }
        semReady = LocalSearch.isLoaded()
    }
    val matched = remember(notes, search, semReady) {
        if (search.isBlank()) null else LocalSearch.search(notes, search)
    }
    val shown = (matched ?: notes).filter { filter == null || it.category == filter }
    val counts = notes.groupingBy { it.category }.eachCount()
    val chipCats = (CATEGORIES + UNSORTED).filter { it.key != "unsorted" || (counts["unsorted"] ?: 0) > 0 }
    val upcoming = remember(notes) {
        val now = System.currentTimeMillis()
        notes.filter { (it.remindAt ?: 0L) > now }.sortedBy { it.remindAt }.take(8)
    }

    // Rows: day headers while browsing, a plain ranked list while searching.
    val rows = ArrayList<LibRow>()
    if (matched != null) {
        shown.forEach { rows.add(LibRow.Item(it)) }
    } else {
        var last = ""
        for (n in shown) {
            val g = groupLabel(n.createdAt)
            if (g != last) {
                rows.add(LibRow.Header(g))
                last = g
            }
            rows.add(LibRow.Item(n))
        }
    }
    val fabExpanded by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(
                title = "سكرتيري",
                subtitle = "ذاكرتك الثانية · ${notes.size} عنصر",
                leading = { Mascot(size = 56.dp) }
            ) { PrivacyBadge(mode, onOpenSettings) }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                placeholder = { Text("ابحث بالمعنى أو بالكلمات (بدون نت)") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        IconButton(onClick = { search = "" }) { Icon(Icons.Filled.Clear, contentDescription = "مسح") }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                item {
                    FilterChip(
                        selected = filter == null,
                        onClick = { filter = null },
                        label = { Text("الكل (${notes.size})") }
                    )
                }
                items(chipCats) { c ->
                    FilterChip(
                        selected = filter == c.key,
                        onClick = { filter = if (filter == c.key) null else c.key },
                        label = { Text("${c.emoji} ${c.label} ${counts[c.key] ?: 0}") }
                    )
                }
            }

            if (notes.isEmpty()) {
                EmptyState(mode, onOpenSettings)
            } else if (rows.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Mascot(size = 96.dp, animated = false)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "ما لقيت شي مطابق 🔎",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (mode == AiMode.OFF) {
                        item(key = "tip") { PrivacyTip(onOpenSettings) }
                    }
                    if (upcoming.isNotEmpty() && search.isBlank() && filter == null) {
                        item(key = "agenda") {
                            AgendaStrip(upcoming) { n -> search = n.title.ifBlank { n.fileName ?: n.text.take(30) } }
                        }
                    }
                    items(
                        rows,
                        key = { r ->
                            when (r) {
                                is LibRow.Header -> "h:" + r.label
                                is LibRow.Item -> r.note.id
                            }
                        }
                    ) { r ->
                        when (r) {
                            is LibRow.Header -> SectionLabel(r.label, Modifier.animateItem())
                            is LibRow.Item -> {
                                val note = r.note
                                NoteCard(
                                    note = note,
                                    modifier = Modifier.animateItem(),
                                    onOpenFile = { FileStore.open(ctx, note) },
                                    onChangeCategory = { key -> scope.launch { dao.update(note.copy(category = key)) } },
                                    onRemind = {
                                        pickDateTime(ctx) { t ->
                                            if (t <= System.currentTimeMillis()) {
                                                say("اختر وقتًا بالمستقبل")
                                            } else {
                                                scope.launch {
                                                    ReminderScheduler.cancel(ctx, note)
                                                    val u = note.copy(remindAt = t)
                                                    dao.update(u)
                                                    ReminderScheduler.schedule(ctx, u)
                                                    say("تم ضبط التذكير ⏰")
                                                }
                                            }
                                        }
                                    },
                                    onClearRemind = {
                                        scope.launch {
                                            ReminderScheduler.cancel(ctx, note)
                                            dao.update(note.copy(remindAt = null))
                                        }
                                    },
                                    onEdit = { editing = note },
                                    onDelete = {
                                        scope.launch {
                                            ReminderScheduler.cancel(ctx, note)
                                            dao.delete(note)
                                            var undone = false
                                            try {
                                                undone = snackbar.showSnackbar(
                                                    message = "تم حذف العنصر",
                                                    actionLabel = "تراجع",
                                                    duration = SnackbarDuration.Short
                                                ) == SnackbarResult.ActionPerformed
                                            } finally {
                                                withContext(NonCancellable + Dispatchers.IO) {
                                                    if (undone) {
                                                        dao.insert(note)
                                                        ReminderScheduler.schedule(ctx, note)
                                                    } else {
                                                        FileStore.deleteCopy(note)
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    onSearch = { search = it },
                                    related = {
                                        val q = (note.title + " " + Keywords.extract(note, 5).joinToString(" ")).trim()
                                        if (q.isBlank()) emptyList()
                                        else LocalSearch.search(notes.filter { it.id != note.id }, q, 3)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            expanded = fabExpanded,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("إضافة") }
        )
    }

    if (showAdd) {
        AddSheet(
            onDismiss = { showAdd = false },
            onSaveText = { t ->
                showAdd = false
                scope.launch { NoteSaver.save(ctx, Note(text = t)) }
            },
            onAttachCopy = {
                showAdd = false
                copyPicker.launch(arrayOf("*/*"))
            },
            onAttachLink = {
                showAdd = false
                linkPicker.launch(arrayOf("*/*"))
            },
            onPasteClipboard = {
                showAdd = false
                val cm = ctx.getSystemService(ClipboardManager::class.java)
                val clip = cm?.primaryClip
                val t = if (clip != null && clip.itemCount > 0 && clip.description.hasMimeType("text/*")) {
                    clip.getItemAt(0).coerceToText(ctx)?.toString()?.trim().orEmpty()
                } else {
                    ""
                }
                if (t.isBlank()) {
                    say("الحافظة فاضية (أو فيها شي مش نص)")
                } else {
                    scope.launch {
                        NoteSaver.save(ctx, Note(text = t))
                        say("تم الحفظ من الحافظة 📋")
                    }
                }
            }
        )
    }

    editing?.let { n ->
        EditDialog(
            note = n,
            onDismiss = { editing = null },
            onSave = { t, x ->
                editing = null
                scope.launch {
                    val changed = t != n.title || x != n.text
                    val u = n.copy(title = t, text = x, embedding = if (changed) null else n.embedding)
                    dao.update(u)
                    if (u.embedding == null) NoteSaver.enqueueClassify(ctx, u.id)
                }
            }
        )
    }
}

@Composable
fun SectionLabel(label: String, modifier: Modifier = Modifier) {
    Text(
        label,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(start = 6.dp, top = 8.dp)
    )
}

@Composable
fun AgendaStrip(items: List<Note>, onClick: (Note) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            "⏰ قادم",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 6.dp)
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(top = 6.dp)
        ) {
            items(items, key = { it.id }) { n ->
                val st = styleOf(n.category)
                Surface(
                    onClick = { onClick(n) },
                    shape = RoundedCornerShape(20.dp),
                    color = st.color.copy(alpha = 0.16f),
                    modifier = Modifier.width(190.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            friendlyDate(n.remindAt ?: 0L),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            n.title.ifBlank { n.fileName ?: n.text.take(40) },
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyState(mode: String, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Mascot(size = 150.dp)
        Spacer(Modifier.height(12.dp))
        Text("ذاكرتك فاضية لسا", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "شارك أي رسالة أو صورة أو ملف من أي تطبيق واختر «سكرتيري»، أو اضغط «إضافة».",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (mode == AiMode.OFF) {
            Spacer(Modifier.height(16.dp))
            FilledTonalButton(onClick = onOpenSettings) { Text("فعّل الذكاء الاصطناعي (اختياري)") }
        }
    }
}

@Composable
fun PrivacyTip(onOpenSettings: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🔒", fontSize = 22.sp)
            Spacer(Modifier.width(10.dp))
            Text(
                "وضع الخصوصية مغلق: كل شي محلي والتصنيف يدوي.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onOpenSettings) { Text("الإعدادات") }
        }
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = 0.16f)) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun KeywordChip(text: String, color: Color, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(10.dp), color = color.copy(alpha = 0.16f)) {
        Text(
            "#$text",
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun NoteCard(
    note: Note,
    modifier: Modifier = Modifier,
    onOpenFile: () -> Unit,
    onChangeCategory: (String) -> Unit,
    onRemind: () -> Unit,
    onClearRemind: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onSearch: (String) -> Unit,
    related: () -> List<Note>
) {
    val st = styleOf(note.category)
    var expanded by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var catMenu by remember { mutableStateOf(false) }
    // Keywords are computed on the phone from the saved text, AI summary and file name.
    val keywords = remember(note.title, note.text, note.summary, note.fileName) { Keywords.extract(note) }
    val relatedNotes = remember(expanded, note.id) { if (expanded) related() else emptyList() }
    val title = note.title.ifBlank {
        note.fileName ?: note.text.lineSequence().firstOrNull().orEmpty().take(50)
    }
    val body = if (note.text.isNotBlank()) note.text else note.summary
    val tint = Brush.verticalGradient(listOf(st.color.copy(alpha = 0.14f), Color.Transparent))

    Card(
        onClick = { expanded = !expanded },
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Box(Modifier.background(tint)) {
            Column(Modifier.padding(16.dp).animateContentSize()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(st.color.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (note.fileName != null) fileEmoji(note.mimeType) else st.emoji, fontSize = 22.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            title.ifBlank { "بدون عنوان" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${st.label} · ${friendlyDate(note.createdAt)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "خيارات")
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (note.fileMode != null) {
                                DropdownMenuItem(text = { Text("فتح الملف") }, onClick = { menu = false; onOpenFile() })
                            }
                            DropdownMenuItem(text = { Text("تغيير التصنيف") }, onClick = { menu = false; catMenu = true })
                            DropdownMenuItem(
                                text = { Text(if (note.remindAt != null) "تغيير التذكير" else "ضبط تذكير") },
                                onClick = { menu = false; onRemind() }
                            )
                            if (note.remindAt != null) {
                                DropdownMenuItem(text = { Text("إلغاء التذكير") }, onClick = { menu = false; onClearRemind() })
                            }
                            DropdownMenuItem(text = { Text("تعديل") }, onClick = { menu = false; onEdit() })
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("حذف", color = MaterialTheme.colorScheme.error) },
                                onClick = { menu = false; onDelete() }
                            )
                        }
                        DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                            CATEGORIES.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.emoji} ${c.label}") },
                                    onClick = { catMenu = false; onChangeCategory(c.key) }
                                )
                            }
                        }
                    }
                }

                if (keywords.isNotEmpty()) {
                    Row(
                        Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        keywords.forEach { k -> KeywordChip(k, st.color) { onSearch(k) } }
                    }
                }

                if (body.isNotBlank()) {
                    Text(
                        body,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = if (expanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
                if (expanded && note.text.isNotBlank() && note.summary.isNotBlank()) {
                    Text(
                        "الملخص: ${note.summary}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                if (note.fileName != null) {
                    Surface(
                        onClick = onOpenFile,
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.padding(top = 10.dp).fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(fileEmoji(note.mimeType), fontSize = 22.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    note.fileName,
                                    style = MaterialTheme.typography.labelLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "📍 ${FileStore.locationLabel(note)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text("افتح", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                note.remindAt?.let {
                    Row(Modifier.padding(top = 10.dp)) { Pill("⏰ ${friendlyDate(it)}", MaterialTheme.colorScheme.primary) }
                }

                if (expanded && relatedNotes.isNotEmpty()) {
                    Text(
                        "🔗 ذكريات مرتبطة",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                    relatedNotes.forEach { r ->
                        val rs = styleOf(r.category)
                        val rt = r.title.ifBlank { r.fileName ?: r.text.take(30) }
                        Surface(
                            onClick = { onSearch(rt) },
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier.padding(top = 6.dp).fillMaxWidth()
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(rs.emoji, fontSize = 16.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(rt, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSheet(
    onDismiss: () -> Unit,
    onSaveText: (String) -> Unit,
    onAttachCopy: () -> Unit,
    onAttachLink: () -> Unit,
    onPasteClipboard: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding()) {
            Text("إضافة جديدة", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                label = { Text("اكتب ملاحظة أو الصق رسالة") },
                minLines = 3,
                maxLines = 8,
                shape = RoundedCornerShape(16.dp)
            )
            Button(
                onClick = { onSaveText(text.trim()) },
                enabled = text.isNotBlank(),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) { Text("حفظ الملاحظة") }
            OutlinedButton(
                onClick = onPasteClipboard,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            ) { Text("📋 احفظ اللي نسخته (الحافظة)") }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAttachCopy, modifier = Modifier.weight(1f)) { Text("📎 أرفق نسخة") }
                OutlinedButton(onClick = onAttachLink, modifier = Modifier.weight(1f)) { Text("🔗 اربط مكان ملف") }
            }
            Text(
                "النسخة: آمنة حتى لو انحذف الأصل. الربط: بدون نسخ، مناسب للملفات الكبيرة.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun EditDialog(note: Note, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var title by remember { mutableStateOf(note.title) }
    var text by remember { mutableStateOf(note.text) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("العنوان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("النص") },
                    minLines = 3,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(title.trim(), text.trim()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
