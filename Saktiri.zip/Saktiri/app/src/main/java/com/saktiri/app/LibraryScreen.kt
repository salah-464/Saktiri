package com.saktiri.app

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LibraryScreen(snackbar: SnackbarHostState, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val dao = remember { AppDatabase.get(ctx).noteDao() }
    val notes by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Note?>(null) }
    val mode = prefs.aiMode

    fun say(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    // Copy mode: duplicates the file inside the app (safe if the original is moved/deleted).
    val copyPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    NoteSaver.save(ctx, FileStore.copyIn(ctx, uri, ""))
                    "تم حفظ نسخة من الملف"
                } catch (e: Exception) {
                    "تعذر حفظ الملف: ${e.message}"
                }
            }
            say(msg)
        }
    }
    // Link mode: remembers only where the file is, and opens it from there later.
    val linkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            scope.launch {
                val msg = withContext(Dispatchers.IO) {
                    try {
                        NoteSaver.save(ctx, FileStore.linked(ctx, uri, ""))
                        "تم ربط الملف (حفظنا مكانه فقط)"
                    } catch (e: Exception) {
                        "تعذر ربط الملف: ${e.message}"
                    }
                }
                say(msg)
            }
        }
    }

    val searchWords = remember(search) {
        TextUtil.words(search).ifEmpty { listOf(TextUtil.norm(search.trim())).filter { it.isNotEmpty() } }
    }
    val shown = notes.filter { n ->
        (filter == null || n.category == filter) &&
            (searchWords.isEmpty() || TextUtil.hay(n).let { h -> searchWords.all { h.contains(it) } })
    }
    val counts = notes.groupingBy { it.category }.eachCount()
    val chipCats = (CATEGORIES + UNSORTED).filter { it.key != "unsorted" || (counts["unsorted"] ?: 0) > 0 }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("سكرتيري", "ذاكرتك الثانية") { PrivacyBadge(mode, onOpenSettings) }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                placeholder = { Text("ابحث في ملاحظاتك وملفاتك") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        IconButton(onClick = { search = "" }) { Icon(Icons.Filled.Clear, contentDescription = "مسح") }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                item {
                    FilterChip(
                        selected = filter == null,
                        onClick = { filter = null },
                        label = { Text("الكل (${notes.size})") }
                    )
                }
                items(chipCats) { c ->
                    FilterChip(
                        selected = filter == c.key,
                        onClick = { filter = if (filter == c.key) null else c.key },
                        label = { Text("${c.emoji} ${c.label} ${counts[c.key] ?: 0}") }
                    )
                }
            }

            if (notes.isEmpty()) {
                EmptyState(mode, onOpenSettings)
            } else if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                    Text(
                        "ما في نتائج مطابقة 🔎",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (mode == AiMode.OFF) {
                        item(key = "tip") { PrivacyTip(onOpenSettings) }
                    }
                    items(shown, key = { it.id }) { note ->
                        NoteCard(
                            note = note,
                            modifier = Modifier.animateItem(),
                            onOpenFile = { FileStore.open(ctx, note) },
                            onChangeCategory = { key -> scope.launch { dao.update(note.copy(category = key)) } },
                            onRemind = {
                                pickDateTime(ctx) { t ->
                                    if (t <= System.currentTimeMillis()) {
                                        say("اختر وقتًا بالمستقبل")
                                    } else {
                                        scope.launch {
                                            ReminderScheduler.cancel(ctx, note)
                                            val u = note.copy(remindAt = t)
                                            dao.update(u)
                                            ReminderScheduler.schedule(ctx, u)
                                            say("تم ضبط التذكير ⏰")
                                        }
                                    }
                                }
                            },
                            onClearRemind = {
                                scope.launch {
                                    ReminderScheduler.cancel(ctx, note)
                                    dao.update(note.copy(remindAt = null))
                                }
                            },
                            onEdit = { editing = note },
                            onDelete = {
                                scope.launch {
                                    ReminderScheduler.cancel(ctx, note)
                                    dao.delete(note)
                                    var undone = false
                                    try {
                                        undone = snackbar.showSnackbar(
                                            message = "تم حذف العنصر",
                                            actionLabel = "تراجع",
                                            duration = SnackbarDuration.Short
                                        ) == SnackbarResult.ActionPerformed
                                    } finally {
                                        withContext(NonCancellable + Dispatchers.IO) {
                                            if (undone) {
                                                dao.insert(note)
                                                ReminderScheduler.schedule(ctx, note)
                                            } else {
                                                FileStore.deleteCopy(note)
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("إضافة") }
        )
    }

    if (showAdd) {
        AddSheet(
            onDismiss = { showAdd = false },
            onSaveText = { t ->
                showAdd = false
                scope.launch { NoteSaver.save(ctx, Note(text = t)) }
            },
            onAttachCopy = {
                showAdd = false
                copyPicker.launch(arrayOf("*/*"))
            },
            onAttachLink = {
                showAdd = false
                linkPicker.launch(arrayOf("*/*"))
            }
        )
    }

    editing?.let { n ->
        EditDialog(
            note = n,
            onDismiss = { editing = null },
            onSave = { t, x ->
                editing = null
                scope.launch {
                    val changed = t != n.title || x != n.text
                    val u = n.copy(title = t, text = x, embedding = if (changed) null else n.embedding)
                    dao.update(u)
                    if (u.embedding == null) NoteSaver.enqueueClassify(ctx, u.id)
                }
            }
        )
    }
}

@Composable
fun EmptyState(mode: String, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🧠", fontSize = 64.sp)
        Spacer(Modifier.height(12.dp))
        Text("ذاكرتك فاضية لسا", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "شارك أي رسالة أو صورة أو ملف من أي تطبيق واختر «سكرتيري»، أو اضغط «إضافة».",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (mode == AiMode.OFF) {
            Spacer(Modifier.height(16.dp))
            FilledTonalButton(onClick = onOpenSettings) { Text("فعّل الذكاء الاصطناعي (اختياري)") }
        }
    }
}

@Composable
fun PrivacyTip(onOpenSettings: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🔒", fontSize = 22.sp)
            Spacer(Modifier.width(10.dp))
            Text(
                "وضع الخصوصية مغلق: كل شي محلي والتصنيف يدوي.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onOpenSettings) { Text("الإعدادات") }
        }
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Surface(shape = CircleShape, color = color.copy(alpha = 0.16f)) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun NoteCard(
    note: Note,
    modifier: Modifier = Modifier,
    onOpenFile: () -> Unit,
    onChangeCategory: (String) -> Unit,
    onRemind: () -> Unit,
    onClearRemind: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val st = styleOf(note.category)
    var expanded by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var catMenu by remember { mutableStateOf(false) }
    val title = note.title.ifBlank {
        note.fileName ?: note.text.lineSequence().firstOrNull().orEmpty().take(50)
    }
    val body = if (note.text.isNotBlank()) note.text else note.summary

    Card(
        onClick = { expanded = !expanded },
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(5.dp).fillMaxHeight().background(st.color))
            Column(Modifier.weight(1f).padding(14.dp).animateContentSize()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(st.color.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) { Text(st.emoji, fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            title.ifBlank { "بدون عنوان" },
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            friendlyDate(note.createdAt),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "خيارات")
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (note.fileMode != null) {
                                DropdownMenuItem(text = { Text("فتح الملف") }, onClick = { menu = false; onOpenFile() })
                            }
                            DropdownMenuItem(text = { Text("تغيير التصنيف") }, onClick = { menu = false; catMenu = true })
                            DropdownMenuItem(
                                text = { Text(if (note.remindAt != null) "تغيير التذكير" else "ضبط تذكير") },
                                onClick = { menu = false; onRemind() }
                            )
                            if (note.remindAt != null) {
                                DropdownMenuItem(text = { Text("إلغاء التذكير") }, onClick = { menu = false; onClearRemind() })
                            }
                            DropdownMenuItem(text = { Text("تعديل") }, onClick = { menu = false; onEdit() })
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("حذف", color = MaterialTheme.colorScheme.error) },
                                onClick = { menu = false; onDelete() }
                            )
                        }
                        DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                            CATEGORIES.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.emoji} ${c.label}") },
                                    onClick = { catMenu = false; onChangeCategory(c.key) }
                                )
                            }
                        }
                    }
                }

                if (body.isNotBlank()) {
                    Text(
                        body,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = if (expanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
                if (expanded && note.text.isNotBlank() && note.summary.isNotBlank()) {
                    Text(
                        "الملخص: ${note.summary}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                if (note.fileName != null) {
                    Surface(
                        onClick = onOpenFile,
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.padding(top = 10.dp).fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(fileEmoji(note.mimeType), fontSize = 22.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    note.fileName,
                                    style = MaterialTheme.typography.labelLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "📍 ${FileStore.locationLabel(note)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text("افتح", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(st.label, st.color)
                    note.remindAt?.let { Pill("⏰ ${friendlyDate(it)}", MaterialTheme.colorScheme.primary) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSheet(
    onDismiss: () -> Unit,
    onSaveText: (String) -> Unit,
    onAttachCopy: () -> Unit,
    onAttachLink: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).imePadding()) {
            Text("إضافة جديدة", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                label = { Text("اكتب ملاحظة أو الصق رسالة") },
                minLines = 3,
                maxLines = 8,
                shape = RoundedCornerShape(16.dp)
            )
            Button(
                onClick = { onSaveText(text.trim()) },
                enabled = text.isNotBlank(),
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            ) { Text("حفظ الملاحظة") }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAttachCopy, modifier = Modifier.weight(1f)) { Text("📎 أرفق نسخة") }
                OutlinedButton(onClick = onAttachLink, modifier = Modifier.weight(1f)) { Text("🔗 اربط مكان ملف") }
            }
            Text(
                "النسخة: آمنة حتى لو انحذف الأصل. الربط: بدون نسخ، مناسب للملفات الكبيرة.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
fun EditDialog(note: Note, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var title by remember { mutableStateOf(note.title) }
    var text by remember { mutableStateOf(note.text) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("العنوان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("النص") },
                    minLines = 3,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(title.trim(), text.trim()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
