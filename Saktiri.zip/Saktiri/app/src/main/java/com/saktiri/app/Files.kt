package com.saktiri.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream

object FileStore {
    private const val MAX_COPY = 100L * 1024 * 1024 // refuse to copy files above 100 MB
    private const val MAX_AI = 10 * 1024 * 1024      // only send files up to 10 MB to the AI
    private val AI_MIMES = setOf(
        "image/png", "image/jpeg", "image/webp", "image/heic", "image/heif", "application/pdf"
    )

    private data class Meta(val name: String, val mime: String, val size: Long)

    private fun meta(ctx: Context, uri: Uri): Meta {
        var name = uri.lastPathSegment ?: "file"
        var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ni >= 0) c.getString(ni)?.let { name = it }
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
        return Meta(name, mime, size)
    }

    /** Copies the file into the app's private storage (safe: survives the original being moved/deleted). */
    fun copyIn(ctx: Context, uri: Uri, caption: String): Note {
        val m = meta(ctx, uri)
        if (m.size > MAX_COPY) throw IOException("الملف أكبر من 100MB، استخدم زر الربط بدل النسخ")
        val dir = File(ctx.filesDir, "saved").apply { mkdirs() }
        val safe = m.name.replace(Regex("[^\\p{L}\\p{N}._-]"), "_")
        val dest = File(dir, "${System.nanoTime()}_$safe")
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("تعذر قراءة الملف")
        input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        return Note(text = caption, fileUri = dest.absolutePath, fileName = m.name, mimeType = m.mime, fileMode = "copy")
    }

    /** Stores only a pointer to the file (no copy). Needs a persistable permission from the file picker. */
    fun linked(ctx: Context, uri: Uri, caption: String): Note {
        val m = meta(ctx, uri)
        return Note(text = caption, fileUri = uri.toString(), fileName = m.name, mimeType = m.mime, fileMode = "link")
    }

    /** Returns (mime, bytes) when the file is an image/PDF small enough for the AI to read, else null. */
    fun readForAi(ctx: Context, note: Note): Pair<String, ByteArray>? {
        val mime = note.mimeType ?: return null
        if (mime !in AI_MIMES) return null
        val path = note.fileUri ?: return null
        val stream: InputStream? = try {
            when (note.fileMode) {
                "copy" -> File(path).inputStream()
                "link" -> ctx.contentResolver.openInputStream(Uri.parse(path))
                else -> null
            }
        } catch (e: Exception) {
            null
        }
        if (stream == null) return null
        val bytes: ByteArray? = stream.use { s ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            var tooBig = false
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_AI) {
                    tooBig = true
                    break
                }
                out.write(buf, 0, n)
            }
            if (tooBig) null else out.toByteArray()
        }
        return bytes?.let { mime to it }
    }

    fun locationLabel(note: Note): String = when (note.fileMode) {
        "copy" -> "محفوظ داخل التطبيق"
        "link" -> runCatching { Uri.decode(Uri.parse(note.fileUri).lastPathSegment ?: "") }
            .getOrDefault("").ifBlank { "رابط خارجي" }
        else -> ""
    }

    fun deleteCopy(note: Note) {
        if (note.fileMode == "copy") note.fileUri?.let { File(it).delete() }
    }

    fun open(ctx: Context, note: Note) {
        try {
            val uri: Uri = when (note.fileMode) {
                "copy" -> FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(note.fileUri!!))
                "link" -> Uri.parse(note.fileUri)
                else -> return
            }
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, note.mimeType ?: "*/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "ما في تطبيق بيفتح هالنوع من الملفات", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "ما قدرت أفتح الملف، يمكن انتقل أو انحذف", Toast.LENGTH_LONG).show()
        }
    }
}
