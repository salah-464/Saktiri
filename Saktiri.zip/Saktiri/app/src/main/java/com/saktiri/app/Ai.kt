package com.saktiri.app

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

object Vec {
    fun normalize(v: FloatArray): FloatArray {
        var s = 0f
        for (x in v) s += x * x
        val n = sqrt(s)
        return if (n == 0f) v else FloatArray(v.size) { v[it] / n }
    }

    fun toBytes(v: FloatArray): ByteArray {
        val bb = ByteBuffer.allocate(v.size * 4)
        bb.asFloatBuffer().put(v)
        return bb.array()
    }

    fun fromBytes(b: ByteArray): FloatArray {
        val fb = ByteBuffer.wrap(b).asFloatBuffer()
        val out = FloatArray(fb.remaining())
        fb.get(out)
        return out
    }

    fun dot(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in 0 until minOf(a.size, b.size)) s += a[i] * b[i]
        return s
    }

    /** The text that represents a note in semantic search. */
    fun docText(n: Note): String =
        listOf(n.title, n.summary, n.text, n.fileName.orEmpty()).filter { it.isNotBlank() }
            .joinToString("\n").take(6000)
}

object TextUtil {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u0640]")

    /** Lowercase + strip Arabic diacritics + unify letter variants, so "الخطة" matches "خطه". */
    fun norm(s: String): String = s.lowercase().replace(diacritics, "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ة', 'ه').replace('ى', 'ي')

    fun words(q: String): List<String> =
        norm(q).split(Regex("\\s+")).map { it.removePrefix("ال") }.filter { it.length >= 2 }

    fun hay(n: Note): String = norm(Vec.docText(n))
}

object GeminiClient {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    private suspend fun post(prefs: Prefs, model: String, method: String, body: JSONObject): JSONObject =
        withContext(Dispatchers.IO) {
            // THE ONLY NETWORK EXIT of the whole app. In privacy mode "off" nothing is ever sent.
            if (prefs.aiMode == AiMode.OFF) throw IllegalStateException("AI is off (privacy mode)")
            val key = prefs.apiKey
            if (key.isBlank()) throw IllegalStateException("No API key")
            val conn = URL("$BASE$model:$method").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 20_000
                conn.readTimeout = 90_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                if (code !in 200..299) throw IOException("HTTP $code: ${resp.take(300)}")
                JSONObject(resp)
            } finally {
                conn.disconnect()
            }
        }

    /** One prompt, optionally with one inline file (image/PDF). Returns the model's text. */
    suspend fun generate(prefs: Prefs, prompt: String, file: Pair<String, ByteArray>? = null): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        // File contents leave the phone only in FULL mode.
        if (file != null && prefs.aiMode == AiMode.FULL) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", file.first)
                        .put("data", Base64.encodeToString(file.second, Base64.NO_WRAP))
                )
            )
        }
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        return post(prefs, prefs.model, "generateContent", body)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
    }

    /** Semantic vector (768 dims, normalized). query=true for questions, false for stored notes. */
    suspend fun embed(prefs: Prefs, text: String, query: Boolean): FloatArray {
        val m = prefs.embedModel
        val body = JSONObject()
            .put("model", "models/$m")
            .put("content", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text.take(8000)))))
            .put("taskType", if (query) "RETRIEVAL_QUERY" else "RETRIEVAL_DOCUMENT")
            .put("outputDimensionality", 768)
        val values = post(prefs, m, "embedContent", body).getJSONObject("embedding").getJSONArray("values")
        return Vec.normalize(FloatArray(values.length()) { values.getDouble(it).toFloat() })
    }
}

data class ClassifyResult(val category: String, val title: String, val remindAt: Long?, val summary: String)

object Classifier {
    private val categories = setOf("university", "debt", "appointment", "idea", "other")

    suspend fun classify(prefs: Prefs, note: Note, file: Pair<String, ByteArray>?): ClassifyResult {
        val now = SimpleDateFormat("yyyy-MM-dd EEEE HH:mm", Locale.US).format(Date())
        val fileInfo = if (note.fileName != null) {
            "\nAttached file name: ${note.fileName} (type: ${note.mimeType})." +
                if (file != null) " The file content is attached; read it." else " The file content is not available; judge from the name."
        } else ""
        val prompt = """
You organize saved notes and files for a university student. Current local date/time: $now.
Reply with ONLY a JSON object, no markdown, in this shape:
{"category": "university|debt|appointment|idea|other", "title": "<=6 words, same language as the content", "summary": "short summary", "remind_at": "yyyy-MM-ddTHH:mm" or null}
Rules:
- "university": study plans, lectures, exams, assignments. "debt": money owed to or by someone. "appointment": meetings and agreements at a time. "idea": ideas and thoughts. "other": anything else.
- summary: one sentence (max 25 words) for text notes; for files, max 60 words covering what it is and the key names, dates and numbers it contains. Use the same language as the content.
- Set remind_at only when there is a deadline, appointment, or debt due date. Use the stated time, or 09:00 on the due date if no hour is given. Resolve relative words (tomorrow, Wednesday) using the current date. Otherwise null.$fileInfo
User text (may be empty):
<note>
${note.text}
</note>
""".trimIndent()
        val raw = GeminiClient.generate(prefs, prompt, file)
        val json = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        val cat = json.optString("category", "other").lowercase().let { if (it in categories) it else "other" }
        val remind = if (json.isNull("remind_at")) null else runCatching {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(json.getString("remind_at"))?.time
        }.getOrNull()
        return ClassifyResult(cat, json.optString("title", "").take(80), remind, json.optString("summary", "").take(500))
    }
}

data class AskResult(val answer: String, val sources: List<Note>)

object Assistant {
    /** Local keyword ranking: works with no network and no AI. */
    fun keywordRank(all: List<Note>, question: String, limit: Int): List<Note> {
        val words = TextUtil.words(question)
        if (words.isEmpty()) return emptyList()
        return all.map { n ->
            val hay = TextUtil.hay(n)
            n to words.count { hay.contains(it) }
        }.filter { it.second > 0 }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    private suspend fun retrieve(prefs: Prefs, all: List<Note>, question: String): List<Note> {
        val picked = LinkedHashMap<Long, Note>()

        // 1) Semantic: nearest notes by meaning.
        val qvec = runCatching { GeminiClient.embed(prefs, question, true) }.getOrNull()
        if (qvec != null) {
            all.filter { it.embedding != null }
                .map { it to Vec.dot(qvec, Vec.fromBytes(it.embedding!!)) }
                .sortedByDescending { it.second }
                .take(12)
                .forEach { picked[it.first.id] = it.first }
        }

        // 2) Keyword: catches exact names/numbers and notes without a vector yet.
        keywordRank(all, question, 8).forEach { picked.putIfAbsent(it.id, it) }

        if (picked.isEmpty()) all.take(20).forEach { picked[it.id] = it }
        return picked.values.toList()
    }

    suspend fun ask(context: Context, question: String): AskResult {
        val prefs = Prefs(context)
        val all = AppDatabase.get(context).noteDao().getAll()
        if (all.isEmpty()) return AskResult("ما في ملاحظات محفوظة لسا.", emptyList())
        if (prefs.aiMode == AiMode.OFF) {
            val hits = keywordRank(all, question, 10)
            val msg = if (hits.isEmpty()) "وضع الخصوصية شغال (بدون ذكاء): ما لقيت نتائج بالكلمات."
            else "وضع الخصوصية شغال (بدون ذكاء): لقيت ${hits.size} نتيجة بالكلمات."
            return AskResult(msg, hits)
        }
        if (prefs.apiKey.isBlank()) return AskResult("ضيف مفتاح API من تبويب الإعدادات أول.", emptyList())

        val chosen = retrieve(prefs, all, question)
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val block = chosen.joinToString("\n---\n") { n ->
            buildString {
                append("#${n.id} [${fmt.format(Date(n.createdAt))}] [${n.category}] ${n.title}\n")
                if (n.summary.isNotBlank()) append("Summary: ${n.summary}\n")
                if (n.text.isNotBlank()) append(n.text.take(600)).append("\n")
                if (n.fileName != null) append("File: ${n.fileName} (${FileStore.locationLabel(n)})\n")
            }
        }
        val prompt = """
You are the user's personal memory assistant. Answer the question using ONLY the saved notes below.
Answer in the same language and dialect as the question. Be short and concrete, mention dates and file names when relevant.
If the notes do not contain the answer, say so plainly. Do not invent details.
Finish with one last line exactly like "IDS: 3,7" listing the note numbers you used (or "IDS:" if none).

Saved notes:
$block

Question: $question
""".trimIndent()
        val raw = GeminiClient.generate(prefs, prompt).trim()
        val m = Regex("(?m)^\\s*IDS:\\s*([0-9,\\s]*)\\s*$").findAll(raw).lastOrNull()
        val ids = m?.groupValues?.get(1)?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet().orEmpty()
        val answer = if (m != null) raw.removeRange(m.range).trim() else raw
        return AskResult(answer, chosen.filter { it.id in ids })
    }
}
