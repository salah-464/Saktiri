package com.saktiri.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Saves whatever text is on the clipboard. Android only lets the app that has window focus read the
 * clipboard, so this invisible activity grabs focus for a moment, reads it, saves it, and closes.
 * Launched from: the app-icon shortcut, the quick-save notification, the Quick Settings tile.
 */
class ClipboardSaveActivity : ComponentActivity() {
    private var handled = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || handled) return
        handled = true
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm?.primaryClip
        val text = if (clip != null && clip.itemCount > 0 && clip.description.hasMimeType("text/*")) {
            clip.getItemAt(0).coerceToText(this)?.toString()?.trim().orEmpty()
        } else {
            ""
        }
        if (text.isBlank()) {
            Toast.makeText(this, "الحافظة فاضية (أو فيها شي مش نص)", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val app = application as SaktiriApp
        lifecycleScope.launch {
            val duplicate = withContext(Dispatchers.IO) {
                AppDatabase.get(app).noteDao().getAll().take(5).any { it.text == text }
            }
            if (duplicate) {
                Toast.makeText(this@ClipboardSaveActivity, "محفوظ من قبل", Toast.LENGTH_SHORT).show()
            } else {
                withContext(Dispatchers.IO) { NoteSaver.save(app, Note(text = text)) }
                Toast.makeText(this@ClipboardSaveActivity, "تم الحفظ في سكرتيري 🧠", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }
}

/** Appears in the text-selection toolbar (⋮ menu) of apps that use Android's standard text selection. */
class ProcessTextActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()?.trim().orEmpty()
        if (text.isBlank()) {
            finish()
            return
        }
        val app = application as SaktiriApp
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { NoteSaver.save(app, Note(text = text)) }
            Toast.makeText(this@ProcessTextActivity, "تم الحفظ في سكرتيري 🧠", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

/** Quick Settings tile: copy a message, pull down the shade, tap the tile. */
class ClipTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, ClipboardSaveActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(
                this, 2, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}

/** Optional ongoing notification: tap it after copying a message to save it. */
object QuickNotif {
    private const val ID = 4242

    @SuppressLint("MissingPermission")
    fun show(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val intent = Intent(ctx, ClipboardSaveActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, SaktiriApp.QUICK_CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("سكرتيري ⚡")
            .setContentText("انسخ أي رسالة، ثم اضغط هنا لحفظها")
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        NotificationManagerCompat.from(ctx).notify(ID, n)
    }

    fun hide(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ID)
    }
}
