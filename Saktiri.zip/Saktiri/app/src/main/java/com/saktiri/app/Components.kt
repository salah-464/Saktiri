package com.saktiri.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class CategoryStyle(val key: String, val label: String, val emoji: String, val color: Color)

val CATEGORIES = listOf(
    CategoryStyle("university", "جامعة", "🎓", Color(0xFF4285F4)),
    CategoryStyle("debt", "ديون", "💰", Color(0xFFE8710A)),
    CategoryStyle("appointment", "مواعيد", "📅", Color(0xFF1E8E3E)),
    CategoryStyle("idea", "أفكار", "💡", Color(0xFFF9AB00)),
    CategoryStyle("other", "أخرى", "📝", Color(0xFF9AA0A6))
)
val UNSORTED = CategoryStyle("unsorted", "غير مصنف", "⏳", Color(0xFF9AA0A6))

fun styleOf(key: String): CategoryStyle = CATEGORIES.firstOrNull { it.key == key } ?: UNSORTED

fun fileEmoji(mime: String?): String = when {
    mime == null -> "📄"
    mime.startsWith("image/") -> "🖼️"
    mime == "application/pdf" -> "📕"
    mime.startsWith("video/") -> "🎞️"
    mime.startsWith("audio/") -> "🎵"
    else -> "📄"
}

/** "اليوم 14:30" / "أمس 09:00" / "بكرا 08:00" / "20 أكتوبر 10:00" */
fun friendlyDate(ts: Long): String {
    fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val days = Math.round((startOfDay(System.currentTimeMillis()) - startOfDay(ts)) / 86_400_000.0).toInt()
    val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(ts))
    return when (days) {
        0 -> "اليوم $time"
        1 -> "أمس $time"
        -1 -> "بكرا $time"
        else -> SimpleDateFormat("d MMM", Locale("ar")).format(Date(ts)) + " " + time
    }
}

/** Whole days between [ts] and today (0 = today, 1 = yesterday, negative = future). */
fun dayDiff(ts: Long): Int {
    fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    return Math.round((startOfDay(System.currentTimeMillis()) - startOfDay(ts)) / 86_400_000.0).toInt()
}

fun groupLabel(ts: Long): String {
    val d = dayDiff(ts)
    return when {
        d <= 0 -> "اليوم"
        d == 1 -> "أمس"
        d <= 7 -> "هذا الأسبوع"
        else -> "أقدم"
    }
}

/** Date then time, using the platform pickers. Caller must pass an Activity context. */
fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    DatePickerDialog(
        ctx,
        { _, y, m, d ->
            TimePickerDialog(
                ctx,
                { _, h, min ->
                    val c = Calendar.getInstance()
                    c.set(y, m, d, h, min, 0)
                    c.set(Calendar.MILLISECOND, 0)
                    onPicked(c.timeInMillis)
                },
                9, 0, true
            ).show()
        },
        now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)
    ).show()
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String,
    leading: (@Composable () -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable
fun PrivacyBadge(mode: String, onClick: () -> Unit) {
    val label = when (mode) {
        AiMode.OFF -> "🔒 خصوصي"
        AiMode.TEXT -> "📝 نص فقط"
        else -> "📎 كامل"
    }
    AssistChip(onClick = onClick, label = { Text(label) })
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}
