Drop wv.bin here (app/src/main/assets/wv.bin) to bundle the offline smart-search vectors inside the APK.
The app loads an imported copy first (Settings > import), then falls back to this file.
