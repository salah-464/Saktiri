#!/usr/bin/env python3
"""
Builds wv.bin: a small Arabic + English static word-vector file for Saktiri's offline smart search.
Target size: well under 10 MB (default ~7 MB).

Run once on Google Colab (works from a phone browser):
  1) colab.research.google.com -> New notebook
  2) paste this whole file into one cell and run it
  3) wv.bin downloads automatically (or find it in the Files panel)
  4) in the app: Settings > "البحث الذكي بدون نت" > import wv.bin

Source vectors: fastText Common Crawl vectors (cc.ar.300 / cc.en.300), licensed CC BY-SA 3.0.
Only the most frequent words are read (the stream is cut early), so the download is a fraction of the full file.
"""
import argparse, gzip, io, math, re, struct, sys, urllib.request
import numpy as np

AR_URL = "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.ar.300.vec.gz"
EN_URL = "https://dl.fbaipublicfiles.com/fasttext/vectors-crawl/cc.en.300.vec.gz"

# MUST match TextUtil.norm() in the app (Ai.kt).
_DIAC = re.compile("[\u064B-\u065F\u0670\u0640]")
def norm(s):
    s = _DIAC.sub("", s.lower())
    for a, b in (("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ة", "ه"), ("ى", "ي")):
        s = s.replace(a, b)
    return s

AR_RE = re.compile(r"^[\u0621-\u064A]{2,15}$")
EN_RE = re.compile(r"^[a-z]{2,15}$")


def open_stream(src):
    raw = urllib.request.urlopen(src) if src.startswith("http") else open(src, "rb")
    return io.TextIOWrapper(gzip.GzipFile(fileobj=raw), encoding="utf-8", errors="ignore")


def read_top(src, n_keep, pattern, label):
    f = open_stream(src)
    header = f.readline().split()
    dim_in = int(header[1])
    words, vecs, ranks, seen = [], [], [], set()
    for rank, line in enumerate(f, start=1):
        parts = line.rstrip().split(" ")
        if len(parts) != dim_in + 1:
            continue
        w = norm(parts[0])
        if w in seen or not pattern.match(w):
            continue
        seen.add(w)
        words.append(w)
        vecs.append(np.array(parts[1:], dtype=np.float32))
        ranks.append(rank)
        if len(words) >= n_keep:
            break
        if len(words) % 5000 == 0:
            print(f"  {label}: {len(words)} words (file rank {rank})", flush=True)
    f.close()
    print(f"{label}: kept {len(words)} words", flush=True)
    return words, np.vstack(vecs), ranks


def reduce(X, dim):
    """Center, project onto the top `dim` principal components, L2-normalise rows."""
    X = X - X.mean(axis=0, keepdims=True)
    C = X.T @ X
    _, V = np.linalg.eigh(C)
    V = V[:, ::-1][:, :dim]
    Y = X @ V
    Y /= (np.linalg.norm(Y, axis=1, keepdims=True) + 1e-9)
    return Y.astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ar", default=AR_URL)
    ap.add_argument("--en", default=EN_URL)
    ap.add_argument("--n-ar", type=int, default=30000)
    ap.add_argument("--n-en", type=int, default=20000)
    ap.add_argument("--dim", type=int, default=128)
    ap.add_argument("--out", default="wv.bin")
    a, _ = ap.parse_known_args()

    words, mats, ranks = [], [], []
    for src, n, pat, label in ((a.ar, a.n_ar, AR_RE, "ar"), (a.en, a.n_en, EN_RE, "en")):
        w, X, r = read_top(src, n, pat, label)
        words += w
        mats.append(reduce(X, a.dim))
        ranks += r
    Y = np.vstack(mats)
    N, D = Y.shape

    scale = np.abs(Y).max(axis=1) / 127.0
    scale[scale == 0] = 1.0
    Q = np.clip(np.round(Y / scale[:, None]), -127, 127).astype(np.int8)
    # idf-like weight: ln(rank+1)*20 as a byte (the app divides by 20)
    wts = bytes(min(255, int(round(20 * math.log(r + 1)))) for r in ranks)

    out = bytearray(b"SKW1")
    out += struct.pack("<IH", N, D)
    for w in words:
        b = w.encode("utf-8")
        out += bytes([len(b)]) + b
    out += wts
    out += struct.pack(f"<{N}f", *scale.astype(np.float32))
    out += Q.tobytes()

    with open(a.out, "wb") as fh:
        fh.write(out)
    mb = len(out) / (1024 * 1024)
    print(f"\nDONE: {a.out}  words={N}  dim={D}  size={mb:.2f} MB")
    if mb >= 10:
        print("WARNING: file is 10 MB or more. Lower --n-ar / --n-en / --dim.")
    try:
        from google.colab import files  # type: ignore
        files.download(a.out)
    except Exception:
        pass


if __name__ == "__main__":
    main()
