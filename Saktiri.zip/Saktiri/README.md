# Saktiri (سكرتيري)
Android app: share any message to "Saktiri" in one tap -> saved, auto-categorized by AI, reminders set. Ask your notes questions.
Stack: Kotlin, Jetpack Compose, Room, WorkManager, Gemini REST API (key entered in Settings).
Features: semantic search (embeddings), save text/images/PDF/any file (copy or link-only), AI reads images and PDFs.
Build: open in Android Studio and Run, OR push to GitHub and download the APK from the Actions tab (.github/workflows/build.yml).

Privacy: Settings > Privacy has 3 modes (default OFF = nothing leaves the phone). The app's only network exit is GeminiClient.post() in Ai.kt.
Hard guarantee: delete the INTERNET permission line from AndroidManifest.xml and Android itself blocks all network access for the app.
Cloud backup is disabled (allowBackup=false).

UI: Material 3 (light/dark follow the system), RTL Arabic, cards with category colors, search + filters, add sheet, per-note menu
(open file, change category, reminder, edit, delete with undo), chat-style Ask screen with sources, settings with privacy modes.

## Offline smart search (no internet, < 10 MB)
Built into the app: trigram BM25 (typos/Arabic forms) + optional static word vectors (meaning).
To enable the meaning part, build wv.bin ONCE:
1. colab.research.google.com > New notebook > paste tools/make_wordvectors.py into one cell > Run (a few minutes, needs internet).
2. wv.bin (about 7 MB) downloads. In the app: Settings > "البحث الذكي بدون نت" > import wv.bin.
Size knobs: --n-ar 30000 --n-en 20000 --dim 128 (words x dim ~ file size). Cross-language matching (Arabic query -> English note) is not supported.
Vectors come from fastText Common Crawl (CC BY-SA 3.0).

## Look & feel
Alien mascot (inspired by the 👾 emoji) in the icon, header, empty states, chat; animated tab transitions, back handling,
saved scroll/chat state, haptics, predictive-back enabled. Cards show offline-extracted #keywords; day headers; "قادم" reminder strip;
"ذكريات مرتبطة" (related notes) when a card is expanded.
