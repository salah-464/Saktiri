# Saktiri (سكرتيري)
Android app: share any message to "Saktiri" in one tap -> saved, auto-categorized by AI, reminders set. Ask your notes questions.
Stack: Kotlin, Jetpack Compose, Room, WorkManager, Gemini REST API (key entered in Settings).
Features: semantic search (embeddings), save text/images/PDF/any file (copy or link-only), AI reads images and PDFs.
Build: open in Android Studio and Run, OR push to GitHub and download the APK from the Actions tab (.github/workflows/build.yml).

Privacy: Settings > Privacy has 3 modes (default OFF = nothing leaves the phone). The app's only network exit is GeminiClient.post() in Ai.kt.
Hard guarantee: delete the INTERNET permission line from AndroidManifest.xml and Android itself blocks all network access for the app.
Cloud backup is disabled (allowBackup=false).

UI: Material 3 (light/dark follow the system), RTL Arabic, cards with category colors, search + filters, add sheet, per-note menu
(open file, change category, reminder, edit, delete with undo), chat-style Ask screen with sources, settings with privacy modes.
